import React from 'react';
import '../assets/style.css';

const Header = () => (
    <p className="header">Header</p>
);

export default Header;