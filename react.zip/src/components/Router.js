import React, { Component } from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom'
import app from '../App'
import Header from './Header';
import Footer from './Footer';

class Router extends Component {
    render() {
        return (
            <BrowserRouter>
                <Switch>
                    <Route exact path="/" Component={Header} />
                    <Route path="/" Component={app} />
                    <Route exact path="/" Component={Footer} />

                </Switch>

            /</BrowserRouter>
        )
    }
}
export default Router;
