import React from "react";
import "../assets/style.css";
import Article from "./Article";
import Section from "./Section";

const Main = () => (
    <div>
        <p className="main">Main</p>
        <Article ArticleText="sample">sample</Article>
        <Section />

    </div>
);

export default Main;