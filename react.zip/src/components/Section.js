import React from "react";
import User from "./User";
import UserList from "./UserList";

const Section = () => {
    return (
        <Section className="wrap">
            <h2>our user post </h2>
            <ul className="post">
                {UserList.map((user, index) => (
                    <User
                        userName={user.name}
                        city={user.city}
                        email={user.email}
                        key={index}
                    />
                ))}
            </ul>
        </Section >
    );
};

export default Section;




