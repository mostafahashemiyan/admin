import React from 'react'

const Article = (props) =>
    (
        <Article ClassName="art"><h2>{props.ArticleText}</h2></Article>
    )
export default Article;