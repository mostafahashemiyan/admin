import React from 'react';
import '../assets/style.css';

const Footer = () => (
    <p className="footer">Footer</p>
);

export default Footer;

